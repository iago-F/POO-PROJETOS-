
/*
 * 
 * Atividade 01
 * Alunos: Gabriel Alex e Iago Ferreira
 *  
 */

public class Edicao {
	private int nroEdi;
	private int volumeEdi;
	private Artigo artigos;
	private RevistaCientifica revistaCientifica;
	
	public Edicao(int nroEdi, int volumeEdi, RevistaCientifica revistaCientifica ,Artigo artigos) {
		this.nroEdi = nroEdi;
		this.volumeEdi = volumeEdi;
		this.artigos = artigos;
		this.revistaCientifica = revistaCientifica;
	}
	
	public int getNroEdi() {
		return this.nroEdi;
	}
	public void setNroEdi(int nroEdi) {
		this.nroEdi = nroEdi;
	}
	public int getVolumeEdi() {
		return this.volumeEdi;
	}
	public void setVolumeEdi(int volumeEdi) {
		this.volumeEdi = volumeEdi;
	}
	public Artigo getArtigos() {
		return this.artigos;
	}
	public void setArtigos(Artigo artigos) {
		this.artigos = artigos;
	}
	public RevistaCientifica getRevistaCientifica() {
		return this.revistaCientifica;
	}
	public void setRevistaCientifica(RevistaCientifica revistaCientifica) {
		this.revistaCientifica = revistaCientifica;
	}

	//ToString
	 public String toString()
	 {
		 return("Revista Cientifica-->\n"+this.getRevistaCientifica()+"\n"+"Numero da Edição: "+"n."+this.getNroEdi()+"\n"+"Volume da Edição: "+"v."+this.getVolumeEdi()+
		        "\n"+""+this.getArtigos());
	 }
	
}

