
/*
 * 
 * Atividade 01
 * Alunos: Gabriel Alex e Iago Ferreira
 *  
 */

public class Artigo {
	private String titArtigo;
	private int pagInicial;
	
	public Artigo(String titArtigo, int pagInicial) {
		this.titArtigo = titArtigo;
		this.pagInicial = pagInicial;
	}
	
	public String getTitArtigo() {
		return this.titArtigo;
	}
	public void setTitArtigo(String titArtigo) {
		this.titArtigo = titArtigo;
	}
	public int getPagInicial() {
		return this.pagInicial;
	}
	public void setPagInicial(int pagInicial) {
		this.pagInicial = pagInicial;
	}

	public String toString() {
		return ("Título do Artigo: " + this.getTitArtigo() +"\nPágina Inicial: " + this.getPagInicial());
	}
	
}
