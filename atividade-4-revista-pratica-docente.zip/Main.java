/*
 * 
 * Atividade 01
 * Alunos: Gabriel Alex e Iago Ferreira
 *  
 */
 
 public class Main
{
	public static void main(String[] args) {
	RevistaCientifica RPD = new RevistaCientifica(25262149,"Revista Prática Docente (RPD)");    
    Artigo art = new Artigo("A CALCULADORA  COMO  RECURSO  DIDÁTICO  PARA  O  ENSINO  DOS NÚMEROS DECIMAIS",1);    
    Edicao Edi = new Edicao(3,7,RPD,art);

    System.out.println(Edi.toString());














	}
	
}
 
 