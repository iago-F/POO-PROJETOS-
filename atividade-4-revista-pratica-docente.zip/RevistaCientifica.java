
/*
 * 
 * Atividade 01
 * Alunos: Gabriel Alex e Iago Ferreira
 *  
 */

public class RevistaCientifica {
	private long issnRev;
	private String titRev;
	
	public RevistaCientifica(long issnRev, String titRev) {
		this.issnRev = issnRev;
		this.titRev = titRev;
	}
	
	public long getIssnRev() {
		return this.issnRev;
	}
	public void setIssnRev(long issnRev) {
		this.issnRev = issnRev;
	}
	public String getTitRev() {
		return this.titRev;
	}
	public void setTitRev(String titRev) {
		this.titRev = titRev;
	}

	//ToString
	public String toString() {
		return (this.getTitRev() +" , "+ "ISSN: " + this.getIssnRev());
	}

}
