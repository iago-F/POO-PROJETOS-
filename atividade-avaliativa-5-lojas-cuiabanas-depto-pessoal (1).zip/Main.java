
/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		//Instanciando as cidades e o estado
		Estado matoGrosso = new Estado("Mato Grosso", "MT");
		Cidade varzeaGrande = new Cidade("Várzea Grande", matoGrosso);
		Cidade cuiaba = new Cidade("Cuiabá", matoGrosso);
		
		//Array de funcionarios
		ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
		
		//Primeiro Vendedor
		Endereco enderecoV1 = new Endereco("Rua Cônego Guimarães", "s/n", "Santa Isabel", "78150-900", varzeaGrande);
		Funcionario vendedor1 = new Vendedor("João Moura da Silva", "06/12/1997", "394.257.779-85",
				enderecoV1, 2750, 5.2);
		funcionarios.add(vendedor1);
		
		//Segundo Vendedor
		Endereco enderecoV2 = new Endereco("Rua Dr. Fernando Ferrari", "198", "Dom Aquino", "78015-185", cuiaba);
		Funcionario vendedor2 = new Vendedor("Maria Eduarda Oliveira", "21/10/1995", "691.274.361-79",
				enderecoV2, 3100, 5.5);
		funcionarios.add(vendedor2);
		
		//Gerente
		Endereco enderecoG = new Endereco("Rua Safira", "345", "Bosque da Saúde", "78050-060", cuiaba);
		Funcionario gerente = new Gerente("Rafael Matos", "26/03/1993", "577.286.995-71",
				enderecoG, 5100);
		funcionarios.add(gerente);
				
		//Saída
		for(int i = 0; i < funcionarios.size(); i++) {
			System.out.println(funcionarios.get(i).obterEtiqueta() + "\n");
		}

	}

}
