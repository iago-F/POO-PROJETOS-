
/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
public class Estado {
	private String nome;
	private String sigla;
	
	public Estado(String nome, String sigla) {
		this.nome = nome;
		this.sigla = sigla;
	}
	
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return this.sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	
}
