
/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
public class Gerente extends Funcionario {
	private double salario;

	public Gerente(String nome, String dtNascimento, String cpf, Endereco endereco, double salario) {
		super(nome, dtNascimento, cpf, endereco);
		this.salario = salario;
	}

	public double getSalario() {
		return this.salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double calcularSalario() {
		return 0;
	}
	
	public String toString() {
		return (super.toStringDadosPessoais() + 
				"\nSalário: R$" + this.getSalario());
	}

	public String obterEtiqueta() {
		return ("Nome: " + this.getNome()  + 
				"\nEndereço: " + super.getEndereco().toString());
	}
}
