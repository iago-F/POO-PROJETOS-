
/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
public class Endereco {
	private String rua;
	private String numero;
	private String bairro;
	private String cep;
	private Cidade cidade;

	public Endereco(String rua, String numero, String bairro, String cep, Cidade cidade) {
		this.rua = rua;
		this.numero = numero;
		this.bairro = bairro;
		this.cep = cep;
		this.cidade = cidade;
	}

	public String getRua() {
		return this.rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getBairro() {
		return this.bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCep() {
		return this.cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Cidade getCidade() {
		return this.cidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}
	
	public String toString() {
		return (this.getRua() + ", " + this.getNumero() + ", " + this.getBairro() + "\n" +
				this.getCidade().getNome() + " - " + this.getCidade().getEstado().getSigla() + "\n"+"Cep: " + this.getCep());
	}
}

