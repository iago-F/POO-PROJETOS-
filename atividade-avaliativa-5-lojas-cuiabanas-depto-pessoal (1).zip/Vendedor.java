
/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
public class Vendedor extends Funcionario {
	private double salario;
	private double percComissao;
	
	public Vendedor(String nome, String dtNascimento, String cpf, Endereco endereco, double salario,
			double percComissao) {
		super(nome, dtNascimento, cpf, endereco);
		this.salario = salario;
		this.percComissao = percComissao;
	}

	public double getSalario() {
		return this.salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public double getPercComissao() {
		return this.percComissao;
	}
	public void setPercComissao(double percComissao) {
		this.percComissao = percComissao;
	}

	public double calcularSalario() {
		return 0;
	}
	
	public String toString() {
		return (super.toStringDadosPessoais() + 
				"\nSalário: R$" + this.getSalario() +
				"\nPorcentagem de Comissão: " + this.getPercComissao() + "%");
	}
	public String obterEtiqueta() {
		return ("Nome: " + this.getNome()  + 
				"\nEndereço: " + super.getEndereco().toString());
	}

}
