
/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
public abstract class Funcionario {
	private String nome;
	private String dtNascimento;
	private String cpf;
	private Endereco endereco;
	
	public Funcionario(String nome, String dtNascimento, String cpf, Endereco endereco) {
		this.nome = nome;
		this.dtNascimento = dtNascimento;
		this.cpf = cpf;
		this.endereco = endereco;
	}

	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDtNascimento() {
		return this.dtNascimento;
	}
	public void setDtNascimento(String dtNascimento) {
		this.dtNascimento = dtNascimento;
	}
	public String getCpf() {
		return this.cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Endereco getEndereco() {
		return this.endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	public abstract double calcularSalario();
	
	public String toStringDadosPessoais() {
		return ("Nome: " + this.getNome() + 
		"\nData de Nascimento: " + this.getDtNascimento() +
		"\nCPF: " + this.getCpf() + 
		"\nEndereço: " + endereco.toString());
	}
	
	public abstract String toString();
	
	public abstract String obterEtiqueta();
}
