/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/

public class Jogo extends Item { 
 
    private int numjogador;
    private String plataforma;
 
     public Jogo ( String plataforma , int numjogador ,  String titulo , String comentarios, double tempominutos)
        {
            super(  titulo , comentarios, tempominutos );
            this.numjogador=numjogador;
            this.plataforma=plataforma;
        }
 
    public void setNumjogador(int numjogador)
    {
        this.numjogador=numjogador;
    }
    
    public int getNumjogador()
    {
        return this.numjogador;
    }
    
    public void setPlataforma(String plataforma)
    {
        this.plataforma=plataforma;
    }
    
    public String getPlataforma()
    {
        return this.plataforma;
    }
    
    public String getDescricao()
    {
        return("Titulo e Plataforma: "+super.getTitulo()+", "+this.getPlataforma());
    }
   
}