import java.util.ArrayList;

/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/
public class Main
{
	public static void main(String[] args) {
	
	Musica m1 = new Musica("Ludovico","Expirence","Muito boa ",4.32);
	Musica m2 = new Musica("Joao Gomes ","Meu Pedaço do Pecado","TOP",3.25);
	Video v1 = new Video("Marcos","Tutorial de como fazer aplicação em JAVA","Não gostei do seu tutorial",10.2);
	Video v2 = new Video("Jadson","Receita de Bolo","Não gostei do seu tutorial",10.2);
	Jogo j1 = new Jogo("Android",10,"FIFA 13","Muito Bom",10.0);
	Jogo j2 = new Jogo("IOS",15,"Mario Bros","Muito Bom",10.0);

    ArrayList<Item> produtos = new ArrayList<Item>();
    
    produtos.add(m1);
    produtos.add(m2);
    produtos.add(v1);
    produtos.add(v2);
    produtos.add(j1);
    produtos.add(j2);
	
    //Valores para complementarem os cabeçalhos
	int contadorOrdemJogo = 0;
	int contadorOrdemVideo = 0; 
	int contadorOrdemMusica = 0;
	
	//Impressão das informações dos itens
	for(int i=0; i<produtos.size(); i++) {
		
		String cabecalho = null;
		
		//Condicionais para saber o tipo da classe para determinar o cabeçalho
		if( produtos.get(i) instanceof Jogo){
			contadorOrdemJogo ++;
			cabecalho = "Jogo " + contadorOrdemJogo;
		}
		else if( produtos.get(i) instanceof Video){
			contadorOrdemVideo ++;
			cabecalho = "Vídeo " + contadorOrdemVideo;
		}
		else{
			contadorOrdemMusica ++;
			cabecalho = "Música " + contadorOrdemMusica;
		}
		//Saída
		System.out.println("\t\t" + cabecalho + "\n" + produtos.get(i).getDescricao() + "\n");
	}
		
	}
}
