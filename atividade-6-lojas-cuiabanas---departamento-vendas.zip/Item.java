/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/

public abstract class Item {
    
    private String titulo; 
    private double tempominutos;
    private String comentarios; 
    
    
    public Item ( String titulo,String comentarios ,double tempominutos )
    {
        this.titulo=titulo;
        this.tempominutos=tempominutos;
        this.comentarios=comentarios;
    }
    
    public void setTitulo(String titulo )
    {
        this.titulo=titulo ;
    }
    
    public String getTitulo()
    {
        return this.titulo;
    }
    
    public void setTempominutos(double tempominutos )
    {
        this.tempominutos=tempominutos ;
    }
    
    public double  getTempominutos()
    {
        return this.tempominutos;
    }
    
    public void setComentarios(String comentarios)
    {
        this.comentarios=comentarios;
    }
    
    public String getComentarios()
    {
        return this.comentarios;
    }
    
    public abstract String getDescricao();
    
}