/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/

public class Video extends Item 
{
    private String diretor ;
    
    public Video( String diretor, String titulo , String comentarios, double tempominutos)
    {
        super( titulo , comentarios, tempominutos);
        this.diretor=diretor;
    }
    
    public void setDiretor(String diretor )
    {
        this.diretor=diretor ;
    }
    
    public String getDiretor()
    {
        return this.diretor;
    }
    
    
     public String getDescricao()
     {
         return("Titulo e Diretor: "+super.getTitulo()+", "+this.getDiretor());
     }
    
}