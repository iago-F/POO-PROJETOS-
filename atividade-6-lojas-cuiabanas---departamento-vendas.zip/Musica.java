/*
Atividade Avaliativa 2 
Alunos : Iago Ferreira e Gabriel Alex

*/

public class Musica extends Item {
    
    private String artista;
    
    public Musica(String artista , String titulo , String comentarios, double tempominutos)
    {
        super( titulo ,comentarios, tempominutos);
        this.artista=artista;
    }
    
    public void setArtista(String artista)
    {
        this.artista=artista;
    }
    
    public String getArtista()
    {
        return this.artista;
    }
    
    
    
    public String getDescricao()
    {
        return("Titulo e Artista: "+super.getTitulo()+", "+this.getArtista());
    }
    
}