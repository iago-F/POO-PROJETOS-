public class Memoria {
    
    private long bytesmemoria;
    private String barramentomemoria;
    
    public Memoria(long bytesmemoria , String barramentomemoria)
    {
     this.setBytesmemoria(bytesmemoria);
     this.setBarramentomemoria(barramentomemoria);
        
    }
    
    public void setBytesmemoria(long bytesmemoria)
    {
        this.bytesmemoria = bytesmemoria;
    }
    
    public long getBytesmemoria()
    {
        return this.bytesmemoria;
    }
    
    public void setBarramentomemoria(String barramentomemoria)
    {
        this.barramentomemoria=barramentomemoria;
        
    }
    
    public String getBarramentomemoria()
    {
        return this.barramentomemoria;
    }
    
    public String printInfo()
    {
        return("MEMORIA :"+"bytes da memoria:"+this.getBytesmemoria()+" , "+"Barramento da memoria: "+this.getBarramentomemoria());
    }
    
    
    
    
    
}