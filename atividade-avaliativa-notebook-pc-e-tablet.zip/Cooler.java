public class Cooler {
    
    private double frequenciacooler;
    
    private long potenciacooler;
    
    public Cooler(double frequenciacooler , long potenciacooler)
    {
        this.setFrequenciacooler(frequenciacooler);
        this.setPotenciacooler(potenciacooler);
        
    }
    
    public void setFrequenciacooler(double frequenciacooler )
    {
        this.frequenciacooler=frequenciacooler ;
    }
    
    public double getFrequenciacooler()
    {
        return this.frequenciacooler;
    }
    
    public void setPotenciacooler(long potenciacooler )
    {
        this.potenciacooler = potenciacooler ;
    }
    
    public long getPotenciacooler()
    {
        return this.potenciacooler;
    }
    
    public String printInfo()
    {
        return("COOLER:"+"Frequencia do Cooler: "+this.getFrequenciacooler()+" , "+"Potencia do cooler:"+this.getPotenciacooler());
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}