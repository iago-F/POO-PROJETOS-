public class Processador {
    
    private String tipoprocessador;
    private double frequenciaprocessador;
    
    public Processador(String tipoprocessador , double frequenciaprocessador)
    {
        this.setTipoprocessador(tipoprocessador);
        this.setFrequenciaprocessador(frequenciaprocessador);
        
    }
    
    public void setTipoprocessador(String tipoprocessador)
    {
        this.tipoprocessador=tipoprocessador;
        
    }
    
    public String getTipoprocessador()
    {
        return this.tipoprocessador;
        
    }
    
     public void setFrequenciaprocessador(double frequenciaprocessador)
    {
        this.frequenciaprocessador=frequenciaprocessador;
        
    }
    
    public double getFrequenciaprocessador()
    {
        return this.frequenciaprocessador;
        
    }
    
    public String toString()
    {
        
        return("PROCESSADOR: "+"Tipo do processador: "+this.getTipoprocessador()+" , "+"Frequencia do Processador: "+this.getFrequenciaprocessador());
    }
    
    
    
    
    
}