public class Notebook {
    
    private Processador processadornote;
    private Memoria memorianote;
    private Cooler coolernote;
    
    public Notebook(Processador processadornote , Memoria memorianote , Cooler coolernote)
    
    {
        this.setProcessadornote(processadornote);
        this.setMemorianote(memorianote);
        this.setCoolernote(coolernote);
        
    }
    
    public void setProcessadornote(Processador processadornote )
    {
        this.processadornote =processadornote ;
        
    }
    public Processador getProcessadornote()
    {
        return this.processadornote;
    }
    
    public void setMemorianote(Memoria memorianote )
    {
        this.memorianote = memorianote ;
        
    }
    public Memoria getMemorianote()
    {
        return this.memorianote;
    }
    
    public void setCoolernote(Cooler coolernote )
    {
        this.coolernote =coolernote;
    }
    public Cooler getCoolernote()
    {
        return this.coolernote;
    }
    
    public String tostring()
    {
        return("Processador do Notebook: "+this.getProcessadornote()+" "+"Memoria do Notebook: "+this.getMemorianote()+" "+"Cooler do Notebook: "+this.getCoolernote());
    }
    
    
    
    
    
    
    
    
    
    
}