public class Tablet{
    
    private Processador processadortablet;
    private Memoria memoriatablet;
    private Cooler coolertablet;
    
    public Tablet(Processador processadortablet , Memoria memoriatablet , Cooler coolertablet )
    {
        this.setProcessadortablet(processadortablet);
        this.setMemoriatablet(memoriatablet);
        this.setCoolertablet(coolertablet);
    }
    
      public void setProcessadortablet(Processador processadortablet)
    {
        this.processadortablet =processadortablet ;
        
    }
    public Processador getProcessadortablet()
    {
        return this.processadortablet;
    }
    
    public void setMemoriatablet(Memoria memoriatablet )
    {
        this.memoriatablet = memoriatablet ;
        
    }
    public Memoria getMemoriatablet()
    {
        return this.memoriatablet;
    }
    
    public void setCoolertablet(Cooler coolertablet )
    {
        this.coolertablet=coolertablet;
    }
    public Cooler getCoolertablet()
    {
        return this.coolertablet;
    }
    
    public String tostring()
    {
        return("Processador do tablet : "+this.getProcessadortablet()+" "+"Memoria do Tablet: "+this.getMemoriatablet()+" "+"Cooler do Tablet: "+this.getCoolertablet());
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}