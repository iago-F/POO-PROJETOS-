/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	
	Processador ProcessadorComputador = new Processador("i7",(double)4.7);
	Processador ProcessadorTablet = new Processador("Snapdragon 865 ", (double)1.8);
	Processador ProcessadorNotebook = new Processador("i5",(double)4.0);
	
	Memoria MemoriaComputador = new Memoria(44l,"DDR3");
	Memoria MemoriaTablet = new Memoria((long)32, "DDR2");
	Memoria MemoriaNotebook = new Memoria((long)64, "DDR4");
	
	Cooler CoolerComputador = new Cooler((double)3.7, (long)6);
	Cooler CoolerTablet = new Cooler((double)2.4, (long)4);
	Cooler CoolerNotebook = new Cooler((double)4.8, (long)8);
	
	
    System.out.println("COMPUTADOR-->\n"+ProcessadorComputador.toString()+" ,\n"+MemoriaComputador.printInfo()+" ,\n "+CoolerComputador.printInfo());
    System.out.println("TABLET-->\n "+ProcessadorTablet.toString()+" ,\n "+MemoriaTablet.printInfo()+" ,\n "+CoolerTablet.printInfo());
	System.out.println("NOTEBOOK-->\n"+ProcessadorNotebook.toString()+" ,\n "+MemoriaNotebook.printInfo()+" ,\n "+CoolerNotebook.printInfo());
	
	
	
	
	
	
	}
}
