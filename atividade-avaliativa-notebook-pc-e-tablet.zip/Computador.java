public class Computador {
    private Processador processadorcomput;
    private Memoria memoriacomput;
    private Cooler coolercomput;
    
    public Computador(Processador processadorcomput , Memoria memoriacomput , Cooler coolercomput )
    {
     this.setProcessadorcomput(processadorcomput);
     this.setMemoriacomput(memoriacomput);
     this.setCoolercomput(coolercomput);
     
        
    }
    
    public void setProcessadorcomput(Processador processadorcomput)
    {
        this.processadorcomput =processadorcomput ;
        
    }
    public Processador getProcessadorcomput()
    {
        return this.processadorcomput;
    }
    
    public void setMemoriacomput(Memoria memoriacomput )
    {
        this.memoriacomput = memoriacomput ;
        
    }
    public Memoria getMemoriacomput()
    {
        return this.memoriacomput;
    }
    
    public void setCoolercomput(Cooler coolercomput )
    {
        this.coolercomput=coolercomput;
    }
    public Cooler getCoolercomput()
    {
        return this.coolercomput;
    }
    
    public String tostring()
    {
        return("Processador do Computador : "+this.getProcessadorcomput()+" "+"Memoria do Computador: "+this.getMemoriacomput()+" "+"Cooler do Computador: "+this.getCoolercomput());
    }
    
    
    
    
    
    
    
    
    
}